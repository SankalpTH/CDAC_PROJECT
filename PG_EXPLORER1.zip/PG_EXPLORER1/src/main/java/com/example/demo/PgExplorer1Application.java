package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgExplorer1Application {
//this is main method
	public static void main(String[] args) {
		SpringApplication.run(PgExplorer1Application.class, args);
	}
}