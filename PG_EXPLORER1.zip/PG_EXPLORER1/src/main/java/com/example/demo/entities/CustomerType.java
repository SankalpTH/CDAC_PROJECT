package com.example.demo.entities;

public enum CustomerType {
	Student,
	Other
}