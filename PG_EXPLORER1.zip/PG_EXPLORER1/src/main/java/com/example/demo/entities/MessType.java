package com.example.demo.entities;

public enum MessType {
Veg,
Non_Veg,
Both
}
