package com.example.demo.entities;

public enum OwnerType {
	 PG_OWNER, // Represents 'PG Owner'
	    MESS_OWNER // Represents 'Mess Owner'
}
